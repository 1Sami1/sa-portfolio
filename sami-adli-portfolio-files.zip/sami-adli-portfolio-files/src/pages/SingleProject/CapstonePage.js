import React from 'react'


function CapstonePage() {
  return (
    <div className='projects-wrapper'>
      <h1 className='projects-h1'>Duke's Steakhouse</h1>
    </div>
  )
}

export default CapstonePage