import React from 'react'

function FooterText() {
  return (
    <footer className='site-footer-text'>
        <p className='site-footer-p'>© 2022 Sami Adli</p>
    </footer>
  )
}

export default FooterText